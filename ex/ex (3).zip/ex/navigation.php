<!--Side Navigation Begin-->

<ul class="nav nav-pills nav-stacked col-lg-2 col-md-2 col-sm-3" style="text-align: center">
    <li class="nav-header" style="padding: 7px;color: #3399FF;font-size: 1.5em">EX DEPARTMENT</li>
        <li><a href="index.php">Home</a></li>
        <li><a href="faculty.php">Faculty</a></li>
        <li><a href="academics.php">Academics</a></li>
        <li><a href="lab.php">Laboratories</a></li>
        <li><a href="research.php">Research and Seminar</a></li>
        <li><a href="student project designs.php">Student Project Designs</a></li>
        <li><a href="student acheivements.php">Student Acheivements</a></li>
        <li><a href="placement.php">Placement</a></li>
        <!-- <li><a href="dept.news Letter.html">Dept. News Letter</a></li>-->
</ul>

<!--Side nav Ends-->