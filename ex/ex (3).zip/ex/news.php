<!--News Section Begin -->

<ul class="nav nav-pills nav-stacked col-lg-2 col-md-2 col-sm-2" style="text-align: center">
  <li class="nav-header" style="padding: 7px;color: #3399FF;font-size: 1.5em;border-bottom-color: red;border-bottom-width: 3px;">News</li>
  <li>No Recent NEWS</li>
</ul>

<!--News Section End -->